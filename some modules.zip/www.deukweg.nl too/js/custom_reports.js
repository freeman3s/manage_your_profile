(function($) {
  Drupal.behaviors.AttBeh = {
    attach: function (context, settings) {
      // jQuery(document).ajaxComplete(function() {
      //   refreshTable();
      // });
    }
  };
})(jQuery);
