<div class="gemiddeld">
  <span>Gemiddeld aantal uitgebrachte offertes:  </span><p><?php print $var6; ?></p>
  <span>Gemiddelde doorlooptijd offertes:        </span><p><?php print $var7; ?></p>
  <span>Gemiddeld aantal geaccepteerde offertes: </span><p><?php print $var8; ?></p>
  <span>Gemiddeld aantal afgewezen offertes:     </span><p><?php print $var9; ?></p>
  <span>Gemiddeld aantal beoordelingen:          </span><p><?php print $var10; ?></p>
  <span>Gemiddelde beoordeling:                  </span><p><?php print $var11; ?></p>
</div>
<script type="text/javascript" src="https://www.google.com/jsapi?autoload={'modules':[{'name':'visualization','version':'1.1','packages':['corechart']}]}"></script>
<div id="piechart" style="width: 600px; height: 300px;"></div>
<script type="text/javascript">
  google.setOnLoadCallback(drawChart, true);
  function drawChart() {
    var all_count = '<?php $all_count = $var1 + $var2 + $var3 + $var4 + $var5;?>';
    var data = google.visualization.arrayToDataTable([
      ['Offertes', 'Count', { role: 'style' }],
      ["Send <?php print '\n' . round($var1 * 100 / $all_count) . '%'; ?>",  <?php print $var1; ?>, '#3366cc'],
      ["Accepted <?php print '\n' . round($var2 * 100 / $all_count) . '%'; ?>",  <?php print $var2; ?>, '#109618'],
      ["Rejected because of acceptance of another offer <?php print '\n' . round($var3 * 100 / $all_count) . '%'; ?>",  <?php print $var3; ?>, '#ff9900'],
      ["Rejected because removal of damage report <?php print '\n' . round($var4 * 100 / $all_count) . '%'; ?>",  <?php print $var4; ?>, '#dc3912'],
      ["Still active <?php print '\n' . round($var5 * 100 / $all_count) . '%'; ?>",  <?php print $var5; ?>, '#990099'],
    ]);

    var options = {
      title: 'Offertes',
      legend: { position: 'none' },
    };

    var chart = new google.visualization.ColumnChart(document.getElementById('piechart'));
    chart.draw(data, options);
  }
</script>
<div class="table-options"></div>
<div class="search-container"></div>
