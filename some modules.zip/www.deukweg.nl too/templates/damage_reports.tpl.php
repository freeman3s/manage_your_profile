<div class="second-section">
  <span>Average number of received offers (number):                               </span><p><?php print $avg_received_offers; ?></p>
  <span>Average rating (rating):                                                  </span><p><?php print $avg_rating; ?></p>
  <span>Average number of days between publication and received offers (number):  </span><p><?php print $avg_days_between_publication_and_received_offers; ?></p>
  <span>Average number of days between publication and accepted offers (number):  </span><p><?php print $avg_days_between_publication_and_accepted_offers; ?></p>
  <span>Average number of days between receiving and accepting an offer (number): </span><p><?php print $avg_days_between_receiving_and_accepted_offers; ?></p>
</div>
<script type="text/javascript" src="https://www.google.com/jsapi?autoload={'modules':[{'name':'visualization','version':'1.1','packages':['corechart']}]}"></script>
<div id="piechart" style="width: 600px; height: 300px;"></div>
<div id="piechart_removal" style="width: 600px; height: 300px;"></div>
<script type="text/javascript">
  google.setOnLoadCallback(drawChart, true);
  function drawChart() {
    var data = google.visualization.arrayToDataTable([
      ['Deukweg is known from', 'Statistics'],
      ['Radio', <?php print $radio; ?>],
      ['Television', <?php print $tv; ?>],
      ['Word-of-mouth', <?php print $wom; ?>],
      ['Search engines', <?php print $search; ?>],
      ['Facebook', <?php print $facebook; ?>],
      ['Twitter', <?php print $twitter; ?>],
      ['Other websites', <?php print $websites; ?>],
      ['Magnet stickers', <?php print $magnet_stickers; ?>],
      ['Highway advertising', <?php print $highway_ad; ?>],
      ['Other, namely...', <?php print $other; ?>]
    ]);
    var options = {
      title: 'Deukweg is known from'
    };
    var chart = new google.visualization.PieChart(document.getElementById('piechart'));
    chart.draw(data, options);
  }

  google.setOnLoadCallback(drawChart_removal, true);
  function drawChart_removal() {
    var data = google.visualization.arrayToDataTable([
      ['Reoson removal', 'Statistics'],
      ['I’m reparing the damage through my insurance company', <?php print $insurance; ?>],
      ['I’m reparing the damage somewhere else', <?php print $elsewhere; ?>],
      ['I repaired the damage through Deukweg.nl', <?php print $deukweg; ?>],
      ['I’m not repairing the damage', <?php print $not; ?>],
      ['I’m selling the car with damage', <?php print $selling; ?>],
      ['The offers are too pricy', <?php print $pricy; ?>],
      ['The repairers are too far away', <?php print $toofar; ?>],
      ['Other, namely...', <?php print $other_removal_reason; ?>]
    ]);
    var options = {
      title: 'Reoson removal'
    };
    var chart = new google.visualization.PieChart(document.getElementById('piechart_removal'));
    chart.draw(data, options);
  }
</script>

<div class="table-options"></div>
<div class="items-per-page"></div>
